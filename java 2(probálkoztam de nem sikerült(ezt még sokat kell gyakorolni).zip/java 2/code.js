
function szin (){
    let gomb=document.getElementById(gomb);
    gomb.innerHTML="<color=i>"
    let letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
    

}




gomb.addEventListener("click",szin)
 
function add(table) {
    let table=document.getElementById(table)
    let tbody = document.getElementById(tbody)
    let gomb2= document.getElementById(gomb2)
      tbody.insertRow(-1);
}
gomb1.addEventListener("click",add)