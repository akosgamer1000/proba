function table() {
 let body=document.body;
 let  table=document.createElement(table)
 let row = table.insertRow(j);
 let cell=row.insertCell(0);
 
}

table();