


let eredmény=document.getElementsById(3);
 function k() {
    let x=document.getElementById("1").nodeValue;
    let y=document.getElementsById("2").nodeValue;
 
//let x=prompt;
//let y=prompt;

    document.getElementsById(3).innerHTML=("x+y")
    if(x<0){
        alert("nem lehet negativ")
        x.innerHTML="0";
    }

    if(y<0){
        alert("nem lehet negativ")
        y.innerHTML="0";
    }
}
let gomb=document.getElementsById("gomb");
gomb.addEventListener("click",k);