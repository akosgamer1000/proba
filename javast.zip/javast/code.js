function table() {
 let body=document.body;
 let  table=document.createElement(table)
 let row = table.insertRow(j);
 table.appendChild(row);
 let cell=row.insertCell(0);
 
}

table();