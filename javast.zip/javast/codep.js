let cell1=document.getElementById("1")
cell1.innerText="<p>1<p>";